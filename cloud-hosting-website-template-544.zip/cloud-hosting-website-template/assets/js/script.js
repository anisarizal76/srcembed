
$(document).ready(function(){
  $('.menu-toggle').click(function(){
    $('.menu-burger').toggleClass('active')
    $('.menu').toggleClass('active')
  });
});
// ---------------------------------------



// ---------------------------------------